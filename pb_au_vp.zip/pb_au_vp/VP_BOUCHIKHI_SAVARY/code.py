#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan 22 11:25:36 2022

@author: thomassavary
"""

### On importe les bibliothèques utiles :
import matplotlib.pyplot as plt
import numpy as np
import math as m


### Définition des fonction utiles pour ce TP:

### Input :
### N : (N+2) points pour discrétiser Omega.
### R : Demi-longueur de Omega --> Omega = ]-R,R[.
### Output :
### A : Matrice de l'énonce.
def create_A(N, R) :
    A = np.zeros((N,N))
    h = (2 * R)/(N + 1)
    A[0,0], A[0,1] = 2., -1.
    for i in range(1, N-1):
        A[i, i-1], A[i,i], A[i, i+1] = -1., 2, -1.
    A[N-1, N-2], A[N-1, N-1] = -1., 2.
    return (1/(h**2)) * A

### Input :
### x : vecteur correspondant aux abscisses
### a : borne pour le potentiel
### R : Demi-longueur de Omega --> Omega = ]-R,R[.
### V0 : Valeur du potentiel
### Output:
### Av : Matrice qui tient compte du potentiel
def create_Av(x, R, a, V0):
    Av = np.zeros((len(x),len(x)))
    for i in range(len(x)):
        if abs(x[i]) <= a :
            Av[i,i] = 0
        elif abs(x[i]) > R :
            return "Erreur : x plus grand que Omega"
        else :
            Av[i,i] = V0
    return Av
        
              
### Choix des paramètres :
N = 100
R = 1.
a = 0.5
V0 = 100.


### Question 4 :
    
### On récupère les éléments propres de A et on les trient :
A = create_A(N,R)
eigen_values, eigen_vectors = np.linalg.eig(A)
index = eigen_values.argsort()[::1]
eigen_values, eigen_vectors = eigen_values[index], eigen_vectors[:, index]

### On compare les fonctions propres théoriques et celles de la mtéhode des 
### différences finies pour certaines valeurs de k.
liste_k = [1, m.floor(100/2), N]
x = np.linspace(-R, R, N+2)
x = x[1:]
x = x[:-1]
for k in liste_k :
    sol_exacte = (1 / m.sqrt(R)) * np.sin((k*np.pi*(x + R))/(2*R))
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize = (10, 3))
    ax1.plot(x, sol_exacte, color = "blue", label = "solution exacte")
    ax1.set_xlabel('x')
    ax1.set_ylabel('y')
    ax2.plot(x, eigen_vectors[:, k-1], color = "orange", label = "Différence finie")
    ax2.set_xlabel('x')
    ax2.set_ylabel('y')
    fig.suptitle("k = " + str(k), fontsize=16)
    fig.legend()


### Question 5 :

### On calcule les erreurs d'approximation sur les valeurs propres :
liste_erreur = []
liste_comp = []
for k in range(1, N+1):
    E_k = ((k**2)*(np.pi**2))/(4*(R**2))
    err_k = abs(E_k - eigen_values[k-1])
    comp_k = k/(N+1)
    liste_erreur.append(err_k)
    liste_comp.append(comp_k)

### On affiche ces erreurs :
plt.figure(figsize = (10, 5))
plt.title("Erreur d'approximation des valeurs propres")
plt.xlabel("k")
plt.ylabel("Erreur d'approximation")
plt.plot(np.linspace(1, N, N), liste_erreur, label = "Erreurs d'approximations");
plt.plot(np.linspace(1, N, N), liste_comp, label = "k/(N+1)");
plt.legend();


### Question 6 :
### Voir la fonction Av dans les fonctions utiles.


### Question 7 :
### Comme on a pas suffisamment étudier la méthode de la puissance inverse en 
### cours, on utilise directement la fonction eig de la librairie numpy.linalg

### On calcule les premières et deuxièmes valeurs propres pour différentes
### valeurs de h avec la valeurs des autres paramètres par défaut.
liste_N = np.array([500, 400, 300, 275, 250, 225, 200, 175, 150, 125, 100, 75, 50, 25, 10, 5])
liste_h = (2*R)/(liste_N + 1)
list_first_eigenvalue = []
list_second_eigenvalue = []
for new_N in liste_N :
    new_x = np.linspace(-R, R, new_N+2)
    new_x = new_x[1:]
    new_x = new_x[:-1]
    new_A = create_A(new_N,R) + create_Av(new_x, R, a, V0)
    new_eigval, new_eigvec = np.linalg.eig(new_A)
    new_index = new_eigval.argsort()[::1]
    new_eigval, new_eigvec = new_eigval[new_index], new_eigvec[:, new_index]
    list_first_eigenvalue.append(new_eigval[0])
    list_second_eigenvalue.append(new_eigval[1])

### On affiche ces valeurs propres :
plt.figure(figsize = (10, 5))
plt.title("Approximations des deux premières valeurs propres de Schrödinger en fonction de h")
plt.xlabel("h")
plt.ylabel("Approximations des valeurs propres de Schrödinger")
plt.plot(liste_h, list_first_eigenvalue, label = "Première valeur propre");
plt.plot(liste_h, list_second_eigenvalue, label = "Deuxième valeur propre");
plt.legend();


### Question 8 :
    
### On calcule les modes propres de l'équation de Schrödinger avec les mêmes
### valeurs pour l'équation avec le potentiel nul.
new_A = create_A(N,R) + create_Av(x, R, a, V0)
new_eigval, new_eigvec = np.linalg.eig(new_A)
new_index = new_eigval.argsort()[::1]
new_eigval, new_eigvec = new_eigval[new_index], new_eigvec[:, new_index]

### On compare les fonctions propres de l'opérateur Laplacien
liste_k = [1, 2]
for k in liste_k :
    plt.figure(figsize=(10,5));
    plt.plot(x, eigen_vectors[:, k-1], label = "Laplacien");
    plt.plot(x, new_eigvec[:, k-1], label = "Schrödinger");
    plt.xlabel("x");
    plt.ylabel("y");
    plt.title("Comparation de la fonction propre n° " + str(k));
    plt.legend();
    plt.plot();

### On peut également comparer les probabilités de trouver la particule :
plt.figure(figsize=(10,5))
plt.plot(x, abs(eigen_vectors[:, 0])**2, label = "Laplacien")
plt.plot(x, abs(new_eigvec[:, 0])**2, label = "Schrödinger")
plt.xlabel("x");
plt.ylabel("|u(x)|^2");
plt.title("Comparation des probabilités de trouver la particule avec k = 0");
plt.legend();
plt.plot();

plt.figure(figsize=(10,5))
plt.plot(x, abs(eigen_vectors[:, 1])**2, label = "Laplacien")
plt.plot(x, abs(new_eigvec[:, 1])**2, label = "Schrödinger")
plt.xlabel("x");
plt.ylabel("|u(x)|^2");
plt.title("Comparation des probabilités de trouver la particule avec k = 1");
plt.legend();
plt.plot();