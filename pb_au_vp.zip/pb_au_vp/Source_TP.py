#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Dec 27 11:32:26 2020

@author: cantin
"""

import matplotlib.pyplot as plt
import numpy as np
import numpy.linalg as npl

import scipy.sparse



# Definition de l'intervalle ]-R,R[ + mesh size
R = 3.0
N = 59
h = 2*R/(N+1)
X = np.linspace(-R,R,N)

# 1D Finite Difference Matrix
def Rig(N):
    A = np.zeros([N,N])

    return A

A = Rig(N)

eigval, eigvec = npl.eig(A)
idx = np.argsort(eigval)
eigval = eigval[idx]
eigvec = eigvec[:,idx]

# First Eigenvector
# Fixer le signe
U1 = eigvec[:,0]
if  U1[1]<0:
    U1 = - U1
    
# Second Eigenvector
# Norlaliser et fixer le signe
U2 = eigvec[:,1]
if  U2[1]<0:
    U2 = - U2 


# Plot Eigenvector and eigenvalues
################


# Potentiel trou
V0 = 10
a=1

################
        
        
    