### Importation des bibliothèques :
import numpy as np
import numpy.linalg as npl
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from matplotlib import cm


### Définitions des fonctions utiles :
    
### Fonction permettant à l'utilisateur de choisir ses paramètres de simulation :
def choisir_Parametres():
    print("Choix des paramètres en espace :")
    print("a  = ? (par défaut -> 2.)")
    a = float(input())
    print("b = ? (par défaut -> 1.)")
    b = float(input())
    print("nptx = ? (par défaut -> 61)")
    nptx = int(input())
    print("npty = ? (par défaut -> 31)")
    npty = int(input())
    print("mu = ? (par défaut -> 0.01)")
    mu = float(input())
    print("vx = ? (par défaut -> 0.)")
    vx = float(input())
    nx, ny = nptx - 2, npty - 2
    hx, hy = a/(nptx - 1), b/(npty - 1)
    xx, yy = (np.linspace(0., a, nptx)).transpose(), (np.linspace(0., b, npty)).transpose()
    xxint, yyint = xx[1:nx+1], yy[1:ny+1]
    return(a, b, mu, vx, nptx, npty, nx, ny, hx, hy, xx, yy, xxint, yyint)

### Fonction permettant à l'utilisateur de choisir les paramètres pour la simulation temporelle:
def choisir_Parametres_Temporel():
    print("")
    print("Choix des paramètres temporels :")
    print("cfl  = ? (par défaut -> 0.2)")
    cfl = float(input())
    print("x0 = ? (par défaut -> 0.25)")
    x0 = float(input())
    print("y0 = ? (par défaut -> 0.5)")
    y0 = float(input())
    print("r0 = ? (par défaut -> 0.1)")
    r0 = float(input())
    print("Tf = ? (par défaut -> 0.8)")
    Tf = float(input())
    return(cfl, x0, y0, r0, Tf)

### Fonction permettant de choisir la condition initiale :
def choisir_CI():
    rep = "0"
    print("")
    print("Choix de la CI")
    while (rep != "1") & (rep != "2"):
        print("CI1 ou CI2 ? (répondre 1 ou 2)")
        rep = input()
    return rep

### Fonction permettant de calculer la matrice de diffusion (voir Poisson_Modia.py):
def A_Neumann(nptx, npty, hx, hy, mu) :

    ### Matrice nulle :
    Z = np.zeros((nptx,nptx))

    ### Identité :
    I = np.eye(nptx)
    I[nptx-1,nptx-3], I[nptx-1,nptx-2], I[nptx-1,nptx-1] = 1./(2.*hx), -2./hx, 3./(2.*hx) 

    ### Matrice B :
    gamma = -mu/(hy**2)
    B = np.zeros((nptx,nptx))
    for i in range(1,nptx-1):
        B[i,i] = gamma

    ### Matrice C :
    alpha = -mu/(hx**2)
    beta = mu*((2/(hx**2)) + (2/(hy**2)))
    C = np.zeros((nptx,nptx))
    C[0,0] = 1
    for i in range(1,nptx-1):
        C[i,i-1], C[i,i], C[i,i+1] = alpha, beta, alpha
    C[nptx-1,nptx-3], C[nptx-1,nptx-2], C[nptx-1,nptx-1] = 1./(2.*hx), -2./hx, 3./(2.*hx)

    ### Matrice A :
    ### Première ligne :
    l1 = np.concatenate((I,Z), axis = 1)
    for i in range(2, npty) :
        l1 = np.concatenate((l1,Z), axis = 1)

    ### Autres lignes :
    for i in range(1, npty-1):
        bloc = np.concatenate((B,C,B), axis = 1)
        for j in range(0,i-1):
            bloc = np.concatenate((Z,bloc), axis = 1)
        for j in range(i+2, npty):
            bloc = np.concatenate((bloc,Z), axis = 1)
        l1 = np.concatenate((l1,bloc), axis = 0)

    ### Dernière ligne :
    ll = np.concatenate((Z,Z), axis = 1)
    for i in range(2,npty-1):
        ll = np.concatenate((ll,Z), axis = 1)
    ll = np.concatenate((ll,I), axis = 1)
    
    ### On retourne la matrice A :
    return np.concatenate((l1,ll), axis = 0)

### Fonction permettant de calculer la matrice d'advection :
def matrice_advection(nptx, npty, hx, vx) :
    
    ### Matrice pour remplir la matrice par bloc :
    coeff = vx/(2.*hx)
    D = np.zeros((nptx,nptx))
    for i in range(1,nptx-1):
        D[i,i-1], D[i,i+1] = -1., 1.
    D = coeff * D
    
    ### Matrice contenant des zéros :
    Z = np.zeros((nptx,nptx))
    
    ### On crée la première ligne :
    l1 = np.concatenate((Z,Z), axis  = 1)
    for i in range(2, npty) :
        l1 = np.concatenate((l1,Z), axis = 1)
    
    ### On crée les autres lignes :
    for i in range(1, npty-1):
        bloc = D
        for j in range(0,i):
            bloc = np.concatenate((Z,bloc), axis = 1)
        for j in range(i+1, npty):
            bloc = np.concatenate((bloc,Z), axis = 1)
        l1 = np.concatenate((l1,bloc), axis = 0)
    
    ### Dernière ligne :
    ll = np.concatenate((Z,Z), axis  = 1)
    for i in range(2, npty) :
        ll = np.concatenate((ll,Z), axis = 1)
    
    ### On retourne la matrice A :
    return np.concatenate((l1,ll), axis = 0)

### Solution exacte pour les conditions mixtes :
def Sol_exact_Mix(a, b, x):
    return np.sin((np.pi*x[1])/b)*(np.cos((np.pi*x[0])/a) - 1)

### Terme source sur l'intérieur du domaine pour les conditions mixtes :
def Source_int_Mix(a, b, x, mu, vx):
    c1, c2 = np.pi/a, np.pi/b
    c3, c4 = c1**2, c2**2
    return mu * (c3*np.sin(c2*x[1])*np.cos(c1*x[0]) + c4*np.sin(c2*x[1])*(np.cos(c1*x[0]) - 1)) - vx*c1*np.sin(c2*x[1])*np.sin(c1*x[0])

### Terme source sur la frontière du domaine pour les conditions mixtes :
def Source_bnd_Mix():
    return 0.

### Solution initiale 1 :
def Sol_init_1(x, x0, y0, r0):
    return np.exp(-((x[0]-x0)/r0)**2 - ((x[1]-y0)/r0)**2)

### Solution initiale 2 :
def Sol_init_2(x, x0, y0, r0):
    if (r0**2 - (x[0] - x0)**2 - (x[1] - y0)**2) > 0 :
        return r0**2 - (x[0] - x0)**2 - (x[1] - y0)**2
    else :
        return 0.

### Fonction permettant d'afficher une solution :
def afficher(sol, nx, ny, xx, yy, titre):
    sol_ = np.reshape(sol,(nx+2 ,ny+2), order = 'F');
    X,Y = np.meshgrid(xx, yy)
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.plot_surface(X, Y, sol_.T, rstride = 1, cstride = 1, cmap = cm.coolwarm);
    ax.set_xlabel('$x$', fontsize=20)
    ax.set_ylabel('$y$', fontsize = 20)
    ax.set_zlabel('$u(x,y)$', fontsize = 20)
    ax.set_title(titre)


### Corps du programme :
    
### On fait choisir à l'utilisateur ses paramètres :
print("Choisir des paramètres personnalisés? (répondre oui ou non)")
choix = input()
if choix == "oui" :
    (a, b, mu, vx, nptx, npty, nx, ny, hx, hy, xx, yy, xxint, yyint) = choisir_Parametres()
    (cfl, x0, y0, r0, Tfinal) = choisir_Parametres_Temporel()
else :
    (a, b, mu, vx, nptx, npty) = (2., 1., 0.01, 0., 61, 31)
    nx, ny = nptx - 2, npty - 2
    hx, hy = a/(nptx - 1), b/(npty - 1)
    xx, yy = (np.linspace(0., a, nptx)).transpose(), (np.linspace(0., b, npty)).transpose()
    xxint, yyint = xx[1:nx+1], yy[1:ny+1]
    (cfl, x0, y0, r0, Tfinal) = (0.2, 0.25, 0.5, 0.1, 0.8)

### On fait choisir la condition initiale :
choix_CI = choisir_CI()

### On crée la solution exacte et les termes sources :
u_ex = np.zeros((nx+2)*(ny+2))
F = np.zeros((nx+2)*(ny+2))
for i in range(nptx):
    for j in range(npty):
        coord = np.array([i*hx,j*hy])
        u_ex[j*(nx+2) + i] = Sol_exact_Mix(a, b, coord)
    if i==0 or i==nptx-1:
        for j in range(npty):
            coord = np.array([i*hx,j*hy])
            F[j*(nx+2) + i] = Source_bnd_Mix()
    else:
        for j in range(npty):
            coord = np.array([i*hx,j*hy])
            if j==0 or j==npty-1:
                F[j*(nx+2) + i] = Source_bnd_Mix()
            else:
                F[j*(nx+2) + i] = Source_int_Mix(a, b, coord, mu, vx)

### Solution numérique :
A = A_Neumann(nptx, npty, hx, hy, mu) + matrice_advection(nptx, npty, hx, vx)
u = npl.solve(A, F)

### On affiche les solutions pour comparer :
afficher(u_ex, nx, ny, xx, yy, "Solution exacte pour les conditions mixtes avec termes advectifs")
afficher(u, nx, ny, xx, yy, "Solution approximée pour les conditions mixtes avec termes advectifs")

### On passe à la simulation temporelle :

### On calcule le nombre de Péclet pour connaître le régime de l'écoulement :
Pe = (a*vx)/mu

### On choisit le pas de temps adéquat (voir rapport) :
if Pe <= 1:
    dt = (hx**2)*(hy**2)*cfl/(mu*(hx**2 + hy**2))
else :
    dt = cfl*hx/vx

### On construit la solution initiale :
u_init = np.zeros((nx+2)*(ny+2))
for i in range(nptx):
     for j in range(npty):
             coord = np.array([0.+i*hx,0.+j*hy])
             if choix_CI == "1" :
                 u_init[j*(nx+2) + i] = Sol_init_1(coord, x0, y0, r0)
             else :
                 u_init[j*(nx+2) + i] = Sol_init_2(coord, x0, y0, r0)
                 
             
### Et on l'affiche :             
uu_init = np.reshape(u_init,(nx+2 ,ny+2),order = 'F');
fig = plt.figure(figsize=(10, 7))
X,Y = np.meshgrid(xx,yy)
ax = plt.axes(projection='3d')
surf = ax.plot_surface(X, Y, uu_init.T, rstride=1, cstride=1, cmap='coolwarm', edgecolor='none')
ax.view_init(60, 35)
plt.pause(1.)
             
## Initialize u by the initial data u0
u = u_init.copy()

# Nombre de pas de temps effectues
nt = int(Tfinal/dt)
Tfinal = nt*dt # on corrige le temps final (si Tfinal/dt n'est pas entier)

# Time loop
for n in range(1,nt+1):
    
    if Pe <= 1 :
        u = u - dt*A.dot(u)
    else :
        u = npl.solve(np.eye(nptx*npty) + (dt/2)*A, (np.eye(nptx*npty) - (dt/2)*A).dot(u))

    # Print solution
    if n%5 == 0:
      plt.figure(1)
      plt.clf()
      fig = plt.figure(figsize=(10, 7))
      ax = plt.axes(projection='3d')
      uu = np.reshape(u,(nx+2 ,ny+2),order = 'F');
      surf = ax.plot_surface(X, Y, uu.T, rstride=1, cstride=1, cmap='coolwarm', edgecolor='none')
      ax.view_init(60, 35)
      plt.title(['Schema explicite avec CFL=%s' %(cfl), '$t=$%s' %(n*dt)])
      plt.pause(0.1)

####################################################################
# comparaison solution exacte avec solution numerique au temps final
j0 = int((npty-1)/2)


plt.figure(2)
plt.clf()
x = np.linspace(0., a,nptx)
plt.plot(x,uu_init[:,j0],x,uu[:,j0],'k') #,x,uexacte,'or')
plt.legend(['Solution initiale','Schema explicite = %s' %(cfl)]) #,'solution exacte'],loc='best')
plt.show()

