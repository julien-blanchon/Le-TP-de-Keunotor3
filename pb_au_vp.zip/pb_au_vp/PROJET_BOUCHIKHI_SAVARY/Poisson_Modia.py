### Importation des bibliothèques :
import numpy as np
import numpy.linalg as npl
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import matplotlib.pyplot as plt


### Définitions des fonctions utiles :
    
### Fonction permettant à l'utilisateur de choisir ses paramètres de simulation :
def choisir_Parametres():
    print("Choix des paramètres en espace :")
    print("a  = ? (par défaut -> 1.)")
    a = float(input())
    print("b = ? (par défaut -> 1.)")
    b = float(input())
    print("nptx = ? (par défaut -> 22)")
    nptx = int(input())
    print("npty = ? (par défaut -> 22)")
    npty = int(input())
    print("mu = ? (par défaut -> 1.)")
    mu = float(input())
    nx, ny = nptx - 2, npty - 2
    hx, hy = a/(nptx - 1), b/(npty - 1)
    xx, yy = (np.linspace(0., a, nptx)).transpose(), (np.linspace(0., b, npty)).transpose()
    xxint, yyint = xx[1:nx+1], yy[1:ny+1]
    return(a, b, mu, nptx, npty, nx, ny, hx, hy, xx, yy, xxint, yyint)
    
### Fonction permet de créer la matrice A de l'énonce pour des conditions de Dirichlet :
def A_Dirichlet(nptx, npty, hx, hy, mu) :

    ### Matrice nulle :
    Z = np.zeros((nptx,nptx))

    ### Identité :
    I = np.eye(nptx)

    ### Matrice B :
    gamma = -mu/(hy**2)
    B = np.zeros((nptx,nptx))
    for i in range(1,nptx-1):
        B[i,i] = gamma

    ### Matrice C :
    alpha = -mu/(hx**2)
    beta = mu*((2/(hx**2)) + (2/(hy**2)))
    C = np.zeros((nptx,nptx))
    C[0,0] = 1
    for i in range(1,nptx-1):
        C[i,i-1], C[i,i], C[i,i+1] = alpha, beta, alpha
    C[nptx-1,nptx-1] = 1

    ### Matrice A :
    ### Première ligne :
    l1 = np.concatenate((I,Z), axis = 1)
    for i in range(2, npty) :
        l1 = np.concatenate((l1,Z), axis = 1)

    ### Autres lignes :
    for i in range(1, npty-1):
        bloc = np.concatenate((B,C,B), axis = 1)
        for j in range(0,i-1):
            bloc = np.concatenate((Z,bloc), axis = 1)
        for j in range(i+2, npty):
            bloc = np.concatenate((bloc,Z), axis = 1)
        l1 = np.concatenate((l1,bloc), axis = 0)

    ### Dernière ligne :
    ll = np.concatenate((Z,Z), axis = 1)
    for i in range(2,npty-1):
        ll = np.concatenate((ll,Z), axis = 1)
    ll = np.concatenate((ll,I), axis = 1)
    
    ### On retourne la matrice A :
    return np.concatenate((l1,ll), axis = 0)

### Fonction permet de créer la matrice A de l'énonce pour des conditions de Neumann et de Dirichlet :
def A_Neumann(nptx, npty, hx, hy, mu) :

    ### Matrice nulle :
    Z = np.zeros((nptx,nptx))

    ### Identité :
    I = np.eye(nptx)
    I[nptx-1,nptx-3], I[nptx-1,nptx-2], I[nptx-1,nptx-1] = 1./(2.*hx), -2./hx, 3./(2.*hx) 

    ### Matrice B :
    gamma = -mu/(hy**2)
    B = np.zeros((nptx,nptx))
    for i in range(1,nptx-1):
        B[i,i] = gamma

    ### Matrice C :
    alpha = -mu/(hx**2)
    beta = mu*((2/(hx**2)) + (2/(hy**2)))
    C = np.zeros((nptx,nptx))
    C[0,0] = 1
    for i in range(1,nptx-1):
        C[i,i-1], C[i,i], C[i,i+1] = alpha, beta, alpha
    C[nptx-1,nptx-3], C[nptx-1,nptx-2], C[nptx-1,nptx-1] = 1./(2.*hx), -2./hx, 3./(2.*hx)

    ### Matrice A :
    ### Première ligne :
    l1 = np.concatenate((I,Z), axis = 1)
    for i in range(2, npty) :
        l1 = np.concatenate((l1,Z), axis = 1)

    ### Autres lignes :
    for i in range(1, npty-1):
        bloc = np.concatenate((B,C,B), axis = 1)
        for j in range(0,i-1):
            bloc = np.concatenate((Z,bloc), axis = 1)
        for j in range(i+2, npty):
            bloc = np.concatenate((bloc,Z), axis = 1)
        l1 = np.concatenate((l1,bloc), axis = 0)

    ### Dernière ligne :
    ll = np.concatenate((Z,Z), axis = 1)
    for i in range(2,npty-1):
        ll = np.concatenate((ll,Z), axis = 1)
    ll = np.concatenate((ll,I), axis = 1)
    
    ### On retourne la matrice A :
    return np.concatenate((l1,ll), axis = 0)

### Solution exacte pour les conditions de dirichlet :
def Sol_exact_Dir(a, b, n, k, x):
    return np.sin((n*np.pi*x[0])/a)*np.sin((k*np.pi*x[1])/b)

### Solution exacte pour les conditions mixtes :
def Sol_exact_Mix(a, b, x):
    return np.sin((np.pi*x[1])/b)*(np.cos((np.pi*x[0])/a) - 1)

### Terme source sur l'intérieur du domaine pour les conditions de Dirichlet:
def Source_int_Dir(a, b, n, k, x, mu):
    return mu * (((np.pi*n)/a)**2 + ((k*np.pi)/b)**2) * np.sin((n*np.pi*x[0])/a) * np.sin((k*np.pi*x[1])/b)

### Terme source sur la frontière du domaine pour les conditions de Dirichlet :
def Source_bnd_Dir():
    return 0.

### Terme source sur l'intérieur du domaine pour les conditions mixtes :
def Source_int_Mix(a, b, x, mu):
    c1, c2 = np.pi/a, np.pi/b
    c3, c4 = c1**2, c2**2
    return mu * (c3*np.sin(c2*x[1])*np.cos(c1*x[0]) + c4*np.sin(c2*x[1])*(np.cos(c1*x[0]) - 1))

### Terme source sur la frontière du domaine pour les conditions mixtes :
def Source_bnd_Mix():
    return 0.

### Fonction permettant d'afficher une solution :
def afficher(sol, nx, ny, xx, yy, titre):
    sol_ = np.reshape(sol,(nx+2 ,ny+2), order = 'F');
    X,Y = np.meshgrid(xx, yy)
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.plot_surface(X, Y, sol_.T, rstride = 1, cstride = 1, cmap = cm.coolwarm);
    ax.set_xlabel('$x$', fontsize=20)
    ax.set_ylabel('$y$', fontsize = 20)
    ax.set_zlabel('$u(x,y)$', fontsize = 20)
    ax.set_title(titre)
    plt.show()

    
### Corps du programme :
    
### On fait choisir à l'utilisateur les paramètres de simulation :
(a, b, mu, nptx, npty, nx, ny, hx, hy, xx, yy, xxint, yyint) = choisir_Parametres()

### On crée les solutions exactes et les termes sources pour les deux types de conditions aux limites :
u_ex_dir = np.zeros((nx+2)*(ny+2))
u_ex_mix = np.zeros((nx+2)*(ny+2))
F_dir = np.zeros((nx+2)*(ny+2))
F_mix = np.zeros((nx+2)*(ny+2))    
for i in range(nptx):
    for j in range(npty):
        coord = np.array([i*hx,j*hy]) 
        u_ex_dir[j*(nx+2) + i] = Sol_exact_Dir(a, b, 1, 1, coord)
        u_ex_mix[j*(nx+2) + i] = Sol_exact_Mix(a, b, coord)
    if i==0 or i==nptx-1:
        for j in range(npty):
            coord = np.array([i*hx,j*hy])
            F_dir[j*(nx+2) + i] = Source_bnd_Dir()
            F_mix[j*(nx+2) + i] = Source_bnd_Mix()
    else:
        for j in range(npty):
            coord = np.array([i*hx,j*hy])
            if j==0 or j==npty-1:
                F_dir[j*(nx+2) + i] = Source_bnd_Dir()
                F_mix[j*(nx+2) + i] = Source_bnd_Mix()
            else:
                F_dir[j*(nx+2) + i] = Source_int_Dir(a, b, 1, 1, coord, mu)
                F_mix[j*(nx+2) + i] = Source_int_Mix(a, b, coord, mu)

### Solution approchée par la méthode des différences finies :                
u_dir = npl.solve(A_Dirichlet(nptx, npty, hx, hy, mu), F_dir)
u_mix = npl.solve(A_Neumann(nptx, npty, hx, hy, mu), F_mix)

### On affiche les solutions pour comparer :
afficher(u_ex_dir, nx, ny, xx, yy, "Solution exacte pour les conditions de Dirichlet")
afficher(u_dir, nx, ny, xx, yy, "Solution approximée pour les conditions de Dirichlet")
afficher(u_ex_mix, nx, ny, xx, yy, "Solution exacte pour les conditions mixtes")
afficher(u_mix, nx, ny, xx, yy, "Solution approximée pour les conditions mixtes")